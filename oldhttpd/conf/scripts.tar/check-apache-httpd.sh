#!/bin/sh

apachebinary="/usr/sbin/httpd"
apacheconfig='/etc/httpd/conf/httpd.conf'

OPTIONS=`grep -v '^#' /etc/httpd/conf/apache-options | grep -v '^$'`
echo "checking apache options and config. Options : "$OPTIONS
$apachebinary $OPTIONS -t -f $apacheconfig

