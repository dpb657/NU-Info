#!/usr/bin/perl -w
# set user group mode on a list of files/directories within a base directory
# replacement for tricky GNU make rule
use strict;

# main
{
	my($usergroup)=shift @ARGV;
	my($mode)=shift @ARGV;
	my($base_dir)=shift @ARGV;
        my($filelist)=@ARGV;
	my(@files)=split(/:/,$filelist);	
	
	die("missing user:group") if(not(defined($usergroup) and ($usergroup ne "")));
	
	die("missing mode") if(not(defined($mode) and ($mode ne "")));
	
	die("missing base directory") if(not(defined($base_dir) and ($base_dir ne "")));

	my($user,$group);
	
	if($usergroup=~ m|^([^\:]+)\:(.*)$|){
		$user=$1;
		$group=$2;
	}else{
		die("invalid user:group: \"$usergroup\"");
	}
	
	die("invalid username: \"$user\"") if(not($user =~ m|^[a-z][a-z0-9]{1,7}$|));
	
	die("invalid groupname: \"$group\"") if(not($group =~ m|^[a-z][a-z0-9]{1,7}$|));
	
	die("mode must be 3 or 4 digit octal: \"$mode\"") if(not($mode =~ m|^[0-7]{3,4}$|));

	die("base directory not found: \"$base_dir\" ") if(not( -d $base_dir ));
	
	my($omode)=oct("0".$mode);

	my($uid)=scalar(getpwnam($user));
	die("no such user: \"$user\"") if(not defined($uid));

	my($gid)=scalar(getgrnam($group));
	die("no such group: \"$group\"") if(not defined($gid));
	
	my($name);
	foreach $name (@files) 
	{
#		my($path)=$base_dir."/".$name;
		my($path)=$base_dir.$name;
		
		if( -e $path ){
			eval {
				chown($uid, $gid, $path);
				chmod($omode, $path);
			};
			if($@){
				print "Error processing \"$path\":".$@."\n"; 
			}
		}else{
			print "Not found: \"$path\"\n"	
		}	
	}	
	
	
	exit 0;	
}
